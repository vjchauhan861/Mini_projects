﻿using Microsoft.EntityFrameworkCore;
using ProjectCustomerCRUD.Models.Domain;

namespace ProjectCustomerCRUD.Data
{
    public class MvcDemoDbContext : DbContext
    {
        public MvcDemoDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Customer> Customer { get; set; }     
                                                         

    }
}
